<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <!-- Styles --> 
        <link rel="stylesheet" href="css/app.css">
    </head>
    <body>
        <nav class="navbar navbar-dark bg-primary" id="navbar">
            <a class="navbar-brand" href="#">
              <img src="img/logo.png"  height="50" alt="">
            </a>
          </nav>

          
          <div class="container container-fix">
          <form>
            <img src="img/jersey.jpg" class="img-fluid" alt="jersey">
            <div class="form-group">
                <label for="inputCity" class="font-weight-bold mt-3">1. Enter Name that should appear at the back of jersey</label>
                <input type="text" class="form-control" id="inputCity">
              </div>
              <div class="form-group">
                <label for="inputNumber" class="font-weight-bold">2. Jersey number that displayed at the back</label>
                <input type="number" class="form-control" id="inputNumber">
              </div>
            <div class="form-group">
              <label for="exampleFormControlSelect1" class="font-weight-bold">
                  3. Select dress size
                </label>
              <select class="form-control" id="exampleFormControlSelect1">
                <option>XS</option>
                <option>S</option>
                <option>M</option>
                <option>L</option>
                <option>XL</option>
                <option>XXL</option>
              </select>
            </div>
            
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\incognito\resources\views/welcome.blade.php ENDPATH**/ ?>