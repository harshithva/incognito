  <?php $__env->startSection('content'); ?>
  <div class="jumbotron text-center">
    <h1 class="display-3">Thank You!</h1>
    <p class="lead"><strong>Please pay jersey money ₹375 on friday 17th jan.</strong></p>
    <hr>
    <p>
      Having trouble? <a href="https://wa.me/919110650853">Contact us</a>
    </p>
    <p class="lead">
      <a class="btn btn-primary btn-sm" href="/" role="button">Continue to homepage</a>
    </p>
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\incognito\resources\views/thankyou.blade.php ENDPATH**/ ?>